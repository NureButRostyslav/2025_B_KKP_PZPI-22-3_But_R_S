# ECG Anomaly Detection
Локальний веб-додаток для аналізу ЕКГ.

## Установка
1. Завантажте датасети MIT-BIH, PTB-XL, CinC 2020 у data/raw/
2. Встановіть Python-залежності: `pip install -r backend/requirements.txt`
3. Встановіть Node.js-залежності: `cd frontend && npm install`
4. Запустіть бекенд: `cd backend && python main.py`
5. Запустіть фронтенд: `cd frontend && npm start`

## Використання
- Завантажте файл ЕКГ (WFDB).
- Отримайте результат: тип аномалії, симптоми, графік.
- Завантажте PDF-звіт.