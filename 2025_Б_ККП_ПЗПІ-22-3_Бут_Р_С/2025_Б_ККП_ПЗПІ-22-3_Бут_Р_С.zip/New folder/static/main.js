document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const selectFilesBtn = document.getElementById('select-files');
    const clearFilesBtn = document.getElementById('clear-files');
    const uploadForm = document.getElementById('upload-form');
    const fileList = document.getElementById('file-list');
    const analyzeButton = document.getElementById('analyze-ecg');
    const tutorialButton = document.getElementById('tutorial-btn');
    const resultDiv = document.getElementById('result');

    function checkFileLimit(files) {
        const extensions = new Set(Array.from(files).map(f => f.name.split('.').pop().toLowerCase()));
        const hasHea = extensions.has('hea');
        const hasDat = extensions.has('dat');
        const hasAtr = extensions.has('atr');
        const hasMat = extensions.has('mat');

        if (hasHea && hasDat && hasAtr && files.length > 3) {
            return { valid: false, message: 'Maximum file limit exceeded. MIT-BIH dataset allows up to 3 files (.hea, .dat, .atr).' };
        }
        if (hasHea && hasDat && !hasAtr && !hasMat && files.length > 2) {
            return { valid: false, message: 'Maximum file limit exceeded. PTB-XL dataset allows up to 2 files (.hea, .dat).' };
        }
        if (hasHea && hasMat && !hasDat && !hasAtr && files.length > 2) {
            return { valid: false, message: 'Maximum file limit exceeded. CinC 2020 dataset allows up to 2 files (.hea, .mat).' };
        }
        if (files.length > 3) {
            return { valid: false, message: 'Maximum file limit exceeded. Please select up to 3 files.' };
        }
        return { valid: true };
    }

    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.style.backgroundColor = '#e6f0ff';
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.style.backgroundColor = '#f7fafc';
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.style.backgroundColor = '#f7fafc';
            dropZone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                const check = checkFileLimit(e.dataTransfer.files);
                if (!check.valid) {
                    resultDiv.textContent = check.message;
                    console.warn(check.message, e.dataTransfer.files.length);
                    return;
                }
                fileInput.files = e.dataTransfer.files;
                console.log('Dropped files:', Array.from(fileInput.files).map(f => f.name));
                updateFileList();
            }
        });
    }

    if (selectFilesBtn && fileInput) {
        selectFilesBtn.addEventListener('click', () => {
            console.log('Select Files button clicked');
            fileInput.click();
        });
    }

    if (clearFilesBtn) {
        clearFilesBtn.addEventListener('click', () => {
            fileInput.value = '';
            updateFileList();
            resultDiv.textContent = '';
            console.log('Files cleared');
        });
    }

    if (fileInput) {
        fileInput.addEventListener('change', () => {
            const check = checkFileLimit(fileInput.files);
            if (!check.valid) {
                fileInput.value = '';
                resultDiv.textContent = check.message;
                console.warn(check.message, fileInput.files.length);
                updateFileList();
                return;
            }
            console.log('Files selected:', Array.from(fileInput.files).map(f => f.name));
            updateFileList();
        });
    }

    function updateFileList() {
        const files = fileInput.files;
        fileList.innerHTML = '<p>Selected files:</p><ul>';
        if (files.length === 0) {
            fileList.innerHTML = '<p>No files selected.</p>';
        } else {
            for (let i = 0; i < files.length; i++) {
                fileList.innerHTML += `<li>${files[i].name}</li>`;
            }
            fileList.innerHTML += '</ul>';
        }
    }
    
    if (uploadForm) {
        uploadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            const patientId = document.getElementById('patient_id').value.trim();
            const files = fileInput.files;
            const resultDiv = document.getElementById('result');

            console.log('Form submitted. Patient ID:', patientId, 'Files:', Array.from(files).map(f => f.name));

            if (!patientId) {
                resultDiv.textContent = 'Please enter a patient ID.';
                console.warn('Patient ID is empty');
                return;
            }

            if (!files.length) {
                resultDiv.textContent = 'Please select at least one file.';
                console.warn('No files selected');
                return;
            }

            if (files.length < 2) {
                resultDiv.textContent = 'Please upload all required files (.hea + .dat/.mat, optionally .atr).';
                console.warn('Insufficient files:', files.length);
                return;
            }

            const formData = new FormData();
            for (let file of files) {
                formData.append('files', file);
            }
            formData.append('patient_id', patientId);

            resultDiv.textContent = '';
            const processingDiv = document.createElement('div');
            processingDiv.textContent = 'Processing...';
            processingDiv.id = 'processing-message';
            fileList.insertAdjacentElement('afterend', processingDiv);

            try {
                const response = await fetch('/predict', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                console.log('Server response:', result);

                if (result.error) {
                    resultDiv.textContent = `Error: ${result.error}`;
                    console.error('Server error:', result.error);
                    return;
                }

                window.location.href = `/result/${result.timestamp}`;
            } catch (error) {
                resultDiv.textContent = `Error: ${error.message}`;
                console.error('Fetch error:', error);
            }
        });
    }

    const downloadButton = document.getElementById('download-pdf');
    if (downloadButton) {
        downloadButton.addEventListener('click', () => {
            const pdfBase64 = downloadButton.getAttribute('data-pdf');
            if (pdfBase64) {
                console.log('Downloading PDF');
                const link = document.createElement('a');
                link.href = `data:application/pdf;base64,${pdfBase64}`;
                link.download = `ecg_report_${new Date().toISOString().replace(/[:.]/g, '')}.pdf`;
                link.click();
            } else {
                console.warn('No PDF data found');
            }
        });
    }

    if (tutorialButton) {
        tutorialButton.addEventListener('click', () => {
            console.log('Tutorial button clicked');
            window.location.href = '/tutorial';
        });
    }

    async function viewPatientHistory(patientId) {
        try {
            const response = await fetch(`/patient/${patientId}/results`);
            const results = await response.json();
            console.log('Patient history response:', results);
            if (results.error) {
                document.getElementById('result').innerHTML = `Error: ${results.error}`;
                return;
            }
            let resultText = `History for Patient ID: ${patientId}<br>`;
            results.forEach((result, i) => {
                resultText += `<br>--- Result ${i + 1} (${result.timestamp}) ---<br>`;
                resultText += `Diagnosis: ${result.diagnosis}<br>`;
                resultText += `Description: ${result.description}<br>`;
                resultText += `Symptoms: ${result.symptoms}<br>`;
                resultText += `Files: ${result.files.join(', ')}<br>`;
                resultText += `<img src="data:image/png;base64,${result.plot_base64}" style="max-width:100%;"><br>`;
                resultText += `<a href="/result/${result.timestamp}">View Result</a><br>`;
            });
            document.getElementById('result').innerHTML = resultText;
        } catch (error) {
            document.getElementById('result').innerHTML = `Error: ${error.message}`;
            console.error('Patient history error:', error);
        }
    }

    window.viewPatientHistory = viewPatientHistory;
});