import os
import sys
import signal
import logging
import base64
import atexit
import numpy as np
from datetime import datetime
from PIL import Image
import io
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from tensorflow.keras.models import load_model
from model.training.model import MacroF1Score
from model.preprocessing.load_data import load_wfdb, load_cinc_signal
from model.preprocessing.preprocess import preprocess_signal
from model.symptoms.symptoms_db import SYMPTOMS
from biosppy.signals import ecg
from pymongo import MongoClient
import bcrypt
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

app = Flask(__name__)
app.secret_key = 'your_secure_secret_key'
UPLOAD_FOLDER = 'Uploads'
REPORTS_FOLDER = r'D:\ecg_tachycardia_detection\reports'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORTS_FOLDER, exist_ok=True)

log_dir = r"D:\ecg_tachycardia_detection\logs\fit"
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, "app_log.txt")

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if logger.handlers:
    logger.handlers.clear()

file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8', delay=False)
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.DEBUG)
stream_handler.setFormatter(file_formatter)
logger.addHandler(stream_handler)

logger.debug("Script app.py started")
if logger.handlers:
    logger.handlers[0].flush()

mongo_client = MongoClient('mongodb://localhost:27017')
db = mongo_client['ecg_database']
doctors_collection = db['doctors']
patients_collection = db['patients']
results_collection = db['results']
logger.info("Connected to MongoDB")
if logger.handlers:
    logger.handlers[0].flush()

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

MODEL_PATH = r'D:\ecg_tachycardia_detection\saved_models\classifier_model.h5'
try:
    def macro_f1_score_wrapper(*args, **kwargs):
        return MacroF1Score(num_classes=10, *args, **kwargs)
    model = load_model(MODEL_PATH, custom_objects={'MacroF1Score': macro_f1_score_wrapper})
    logger.info(f"Loaded model from {MODEL_PATH}")
except Exception as e:
    logger.error(f"Failed to load model from {MODEL_PATH}: {str(e)}")
    raise

class_map = {
    0: 'normal', 1: 'af', 2: 'pvc', 3: 'pac', 4: 'mi',
    5: 'lbbb', 6: 'rbbb', 7: 'i-avb', 8: 'sttc', 9: 'hyp'
}

class User(UserMixin):
    def __init__(self, doctor_id, username):
        self.id = doctor_id
        self.username = username

@login_manager.user_loader
def load_user(doctor_id):
    doctor = doctors_collection.find_one({'_id': doctor_id})
    if doctor:
        return User(doctor['_id'], doctor['username'])
    return None

def plot_signal(signal, fs=360):
    """Створює графік ECG із R-піками."""
    logger.info("Creating ECG plot with R-peaks")
    plt.figure(figsize=(10, 4))
    t = np.arange(len(signal)) / fs
    plt.plot(t, signal[:, 0], label='Channel 1')
    plt.plot(t, signal[:, 1], label='Channel 2')
    try:
        ecg_out = ecg.ecg(signal=signal[:, 0], sampling_rate=fs, show=False)
        rpeaks = ecg_out['rpeaks'] / fs
        plt.plot(rpeaks, signal[ecg_out['rpeaks'], 0], 'ro', label='R-peaks')
    except Exception as e:
        logger.warning(f"Failed to detect R-peaks: {str(e)}")
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

def generate_pdf(diagnosis, image_base64, symptoms, probabilities, timestamp, saved_files, patient_id):
    """Генерує PDF-звіт із результатами аналізу."""
    logger.info("Generating PDF report")
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(100, 750, "ECG Diagnosis Report")
    display_date = datetime.strptime(timestamp, '%Y%m%d_%H%M%S').strftime('%B %d, %Y, %I:%M %p')
    c.drawString(100, 730, f"Date: {display_date}")
    c.drawString(100, 710, f"Patient ID: {patient_id}")
    c.drawString(100, 690, f"Diagnosis: {diagnosis}")
    c.drawString(100, 670, f"Description: {symptoms.get('description', 'N/A')}")
    symptoms_text = symptoms.get('symptoms', 'N/A')
    text_object = c.beginText(100, 650)
    text_object.setFont("Helvetica", 12)
    text_object.textLine("Symptoms:")
    text_object.textLine(symptoms_text.strip())
    c.drawText(text_object)
    c.drawString(100, 590, "Probabilities:")
    y = 570
    for k, v in probabilities.items():
        c.drawString(120, y, f"{k}: {v*100:.2f}%")
        y -= 20
    c.drawString(100, y - 20, f"Files: {', '.join([os.path.basename(f) for f in saved_files])}")
    image_data = base64.b64decode(image_base64)
    img = Image.open(io.BytesIO(image_data))
    img.save('temp.png')
    c.drawImage('temp.png', 100, y - 230, width=400, height=200)
    c.showPage()
    c.save()
    os.remove('temp.png')
    buf.seek(0)
    pdf_filename = f"report_{timestamp}.pdf"
    pdf_path = os.path.join(REPORTS_FOLDER, pdf_filename)
    with open(pdf_path, 'wb') as f:
        f.write(buf.getvalue())
    logger.info(f"Saved PDF to {pdf_path}")
    return base64.b64encode(buf.read()).decode('utf-8'), pdf_path

@app.template_filter('strftime')
def _jinja2_filter_datetime(date_str):
    """Форматує дату для шаблонів Jinja2."""
    date = datetime.strptime(date_str, '%Y%m%d_%H%M%S')
    return date.strftime('%B %d, %Y, %I:%M %p')

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        doctor = doctors_collection.find_one({'username': username})
        if doctor and bcrypt.checkpw(password.encode('utf-8'), doctor['password']):
            user = User(doctor['_id'], doctor['username'])
            login_user(user)
            logger.info(f"Doctor {username} logged in")
            return redirect(url_for('home'))
        flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    logger.info("Doctor logged out")
    return redirect(url_for('login'))

@app.route('/home')
@login_required
def home():
    return render_template('home.html')

@app.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    results = []
    query = None
    category = 'patients'
    if request.method == 'POST':
        query = request.form.get('query')
        category = request.form.get('category', 'patients')
        if category == 'patients':
            results = list(patients_collection.find({
                'doctor_id': current_user.id,
                'patient_id': {'$regex': query, '$options': 'i'}
            }))
        elif category == 'results':
            results = list(results_collection.find({
                'doctor_id': current_user.id,
                'patient_id': {'$regex': query, '$options': 'i'}
            }, {'_id': 0}))
    return render_template('search.html', results=results, query=query, category=category)

@app.route('/notifications')
@login_required
def notifications():
    results = list(results_collection.find(
        {'doctor_id': current_user.id}, {'_id': 0}).sort('timestamp', -1).limit(10))
    return render_template('notifications.html', results=results)

@app.route('/success')
@login_required
def success():
    return render_template('success.html')

@app.route('/cardio-home')
@login_required
def cardio_home():
    return render_template('cardio_home.html')

@app.route('/result/<timestamp>')
@login_required
def result(timestamp):
    result_data = results_collection.find_one({
        'doctor_id': current_user.id,
        'timestamp': timestamp
    }, {'_id': 0})
    if not result_data:
        flash('Result not found')
        return redirect(url_for('error_page'))
    logger.info(f"Displaying result for timestamp: {timestamp}, patient_id: {result_data['patient_id']}")
    return render_template('result.html', result=result_data)

@app.route('/tutorial')
@login_required
def tutorial():
    return render_template('tutorial.html')

@app.route('/error')
def error_page():
    return render_template('error.html')

@app.route('/patients', methods=['GET', 'POST'])
@login_required
def patients():
    if request.method == 'POST':
        if 'delete' in request.form:
            patient_id = request.form.get('patient_id')
            patient = patients_collection.find_one({'patient_id': patient_id, 'doctor_id': current_user.id})
            if patient:
                patients_collection.delete_one({'patient_id': patient_id, 'doctor_id': current_user.id})
                results_collection.delete_many({'patient_id': patient_id, 'doctor_id': current_user.id})
                flash(f'Patient {patient_id} and all associated results deleted successfully')
                logger.info(f"Doctor {current_user.username} deleted patient {patient_id} and associated results")
            else:
                flash('Patient not found or not assigned to you')
        else:
            patient_id = request.form.get('patient_id')
            name = request.form.get('name')
            if patients_collection.find_one({'patient_id': patient_id}):
                flash('Patient ID already exists')
            else:
                patients_collection.insert_one({
                    'patient_id': patient_id,
                    'name': name,
                    'doctor_id': current_user.id
                })
                logger.info(f"Added patient {patient_id} for doctor {current_user.id}")
                flash('Patient added successfully')
    patients = list(patients_collection.find({'doctor_id': current_user.id}))
    return render_template('patients.html', patients=patients)

@app.route('/patient/<patient_id>/results', methods=['GET'])
@login_required
def get_patient_results(patient_id):
    try:
        patient = patients_collection.find_one({'patient_id': patient_id, 'doctor_id': current_user.id})
        if not patient:
            logger.error(f"Patient {patient_id} not found or not assigned to doctor {current_user.id}")
            return jsonify({'error': 'Patient not found or not assigned to you'}), 404
        results = list(results_collection.find({'patient_id': patient_id, 'doctor_id': current_user.id}, {'_id': 0}))
        if not results:
            logger.info(f"No results found for patient {patient_id}")
            return jsonify({'error': 'No results found for patient_id'}), 404
        logger.info(f"Found {len(results)} results for patient {patient_id}")
        return jsonify(results)
    except Exception as e:
        logger.error(f"Error fetching results for {patient_id}: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    try:
        files = request.files.getlist('files')
        patient_id = request.form.get('patient_id', 'unknown')
        logger.info(f"Received {len(files)} files for patient_id: {patient_id}")
        logger.debug(f"Files: {[f.filename for f in files]}")

        patient = patients_collection.find_one({'patient_id': patient_id, 'doctor_id': current_user.id})
        if not patient:
            logger.error(f"Patient ID {patient_id} not found or not assigned to doctor {current_user.id}")
            flash('Patient ID not found or not assigned to you')
            return jsonify({'error': 'Patient not found'}), 404

        if not files:
            logger.warning('No files uploaded')
            flash('No files uploaded')
            return jsonify({'error': 'No files selected'}), 400

        saved_files = []
        for file in files:
            file_path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(file_path)
            saved_files.append(file_path)
        logger.info(f"Saved files: {[os.path.basename(f) for f in saved_files]}")

        if not any(f.endswith('.hea') for f in saved_files):
            logger.error('No .hea file found in uploaded files')
            flash('At least one .hea file is required')
            return jsonify({'error': 'At least one .hea file is required'}), 400

        extensions = {os.path.splitext(f)[1].lower() for f in saved_files}
        has_hea = '.hea' in extensions
        has_dat = '.dat' in extensions
        has_atr = '.atr' in extensions
        has_mat = '.mat' in extensions

        if has_mat and not has_dat and has_hea:
            dataset = 'cinc2020'
        elif has_atr and has_dat and has_hea:
            dataset = 'mitdb'
        elif has_dat and has_hea and not has_atr:
            dataset = 'ptbxl'
        else:
            logger.error(f"Invalid file combination: extensions={extensions}")
            flash('Invalid file combination. Use .hea+.dat+.atr, .hea+.dat, or .hea+.mat')
            return jsonify({'error': 'Invalid file combination'}), 400

        hea_file = next(f for f in saved_files if f.endswith('.hea'))
        base_path = hea_file[:-4]
        logger.info(f"Processing .hea file: {hea_file}, dataset: {dataset}")

        signal = None
        annotation = None
        if dataset == 'cinc2020':
            if not any(f.endswith('.mat') and os.path.basename(f)[:-4] == os.path.basename(base_path) for f in saved_files):
                logger.error(f"No matching .mat file found for {base_path}")
                flash('Matching .mat file for .hea is required for CinC 2020')
                return jsonify({'error': 'Matching .mat file required'}), 400
            signal = load_cinc_signal(base_path, target_fs=360, min_length=1.0, channels=[0, 1])
            if signal is None:
                logger.error(f'Failed to load CinC 2020 signal from {base_path}')
                flash(f'Failed to load CinC 2020 signal from {base_path}')
                return jsonify({'error': 'Failed to load data'}), 500
            with open(hea_file, 'r', encoding='utf-8') as f:
                header = f.readlines()
                dx_line = next((l for l in header if l.strip().startswith('# Dx:')), '')
                dx = dx_line.split(':', 1)[1].strip().split(',') if dx_line else ['NORM']
                annotation = {'dataset': 'cinc2020', 'Dx': dx}
        else:
            if not any(f.endswith('.dat') and os.path.basename(f)[:-4] == os.path.basename(base_path) for f in saved_files):
                logger.error(f"No matching .dat file for {base_path}")
                flash('Matching .dat file for .hea is required')
                return jsonify({'error': 'Matching .dat file required'}), 400
            signal, annotation = load_wfdb(base_path, target_fs=360, min_length=1.0, channels=[0, 1])
            if signal is None:
                logger.error(f'Failed to load WFDB signal from {base_path}')
                flash(f'Failed to load WFDB signal from {base_path}')
                return jsonify({'error': 'Failed to load data'}), 500
            if dataset == 'mitdb':
                if not any(f.endswith('.atr') and os.path.basename(f)[:-4] == os.path.basename(base_path) for f in saved_files):
                    logger.error(f"No matching .atr file for {base_path}")
                    flash('Matching .atr file for .hea is required for MIT-BIH')
                    return jsonify({'error': 'Matching .atr file required'}), 400
                annotation = {'dataset': 'mitdb', 'annotation': annotation}
            else: 
                annotation = {'dataset': 'ptbxl', 'diagnostic_class': 'NORM', 'diagnostic_subclass': ''}

        logger.info("Preprocessing signal")
        segments, labels = preprocess_signal(signal, fs=360, segment_length=10, dataset=dataset, annotation=annotation)
        if len(segments) == 0:
            logger.error('No valid segments extracted from signal')
            flash('No valid segments extracted from signal')
            return jsonify({'error': 'No valid segments'}), 500

        logger.info("Making predictions")
        try:
            predictions = model.predict(segments)
            predictions_mean = np.mean(predictions, axis=0)
            predicted_class = np.argmax(predictions_mean)
            diagnosis = class_map.get(predicted_class, 'unknown')
            probabilities = {class_map[i].upper(): float(p) for i, p in enumerate(predictions_mean)}
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            flash(f"Error during prediction: {str(e)}")
            return jsonify({'error': f"Prediction error: {str(e)}"}), 500

        symptoms = SYMPTOMS.get(diagnosis.lower(), {'description': 'N/A', 'symptoms': 'N/A'})
        logger.info(f"Diagnosis: {diagnosis}, Symptoms: {symptoms}")

        image = plot_signal(signal)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        pdf, pdf_path = generate_pdf(diagnosis.upper(), image, symptoms, probabilities, timestamp, saved_files, patient_id)

        result_doc = {
            'patient_id': patient_id,
            'doctor_id': current_user.id,
            'timestamp': timestamp,
            'diagnosis': diagnosis.upper(),
            'probabilities': probabilities,
            'description': symptoms['description'],
            'symptoms': symptoms['symptoms'],
            'plot_base64': image,
            'pdf_base64': pdf,
            'pdf_path': pdf_path,
            'files': [os.path.basename(f) for f in saved_files],
            'dataset': dataset
        }
        try:
            results_collection.insert_one(result_doc)
            logger.info(f"Saved result to MongoDB for patient_id: {patient_id}")
        except Exception as e:
            logger.error(f"Error saving to MongoDB: {str(e)}")
            flash("Error saving result to MongoDB")
            return jsonify({'error': 'Failed to save result to MongoDB'}), 500

        for file_path in saved_files:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                logger.warning(f"Error removing file {file_path}: {str(e)}")
        logger.info("Cleaned up uploaded files")

        logger.info(f"Returning timestamp: {timestamp}")
        return jsonify({'timestamp': timestamp})

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        flash(f"Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def cleanup():
    """Очищення ресурсів при завершенні роботи."""
    logger.info("Cleaning up resources")
    plt.close('all')
    try:
        mongo_client.close()
    except Exception as e:
        logger.error(f"Error closing MongoDB connection: {str(e)}")

atexit.register(cleanup)

def signal_handler(sig, frame):
    """Обробка сигналів завершення."""
    logger.info("Received shutdown signal")
    cleanup()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == '__main__':
    app.run(debug=True, port=5000, use_reloader=False)