import numpy as np

def augment_signal(signal, noise_factor=0.01):
    noise = np.random.normal(0, noise_factor, signal.shape)
    return signal + noise