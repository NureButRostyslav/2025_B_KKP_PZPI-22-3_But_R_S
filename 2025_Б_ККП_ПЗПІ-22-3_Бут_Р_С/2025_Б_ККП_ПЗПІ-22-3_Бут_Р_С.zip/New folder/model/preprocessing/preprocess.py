import numpy as np
from scipy.signal import butter, filtfilt, resample
import logging
import ast

logger = logging.getLogger(__name__)

def preprocess_signal(signal, fs=360, segment_length=10, dataset=None, annotation=None, augment=False):

    lowcut, highcut = 0.5, 40
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(4, [low, high], btype='band')
    signal = np.apply_along_axis(lambda x: filtfilt(b, a, x), 0, signal)

    if np.any(np.isnan(signal)) or np.any(np.isinf(signal)):
        logger.warning("Signal contains NaN or Inf, replacing with zeros")
        signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)

    samples_per_segment = int(segment_length * fs)
    if len(signal) < samples_per_segment:
        logger.warning(f"Signal too short: {len(signal)} samples, required {samples_per_segment}. Skipping.")
        return np.array([]), []

    segments = []
    labels = []
    step = samples_per_segment // 2
    for i in range(0, len(signal) - samples_per_segment + 1, step):
        segment = signal[i:i + samples_per_segment]
        if np.std(segment) == 0:
            logger.warning(f"Skipping segment {i} with zero standard deviation")
            continue
        segment = (segment - np.mean(segment, axis=0)) / (np.std(segment, axis=0) + 1e-10)
        if augment:
            segment += np.random.normal(0, 0.01, segment.shape)
            scale = np.random.uniform(0.9, 1.1)
            segment *= scale
            shift = np.random.uniform(-0.1, 0.1)
            segment += shift
            if np.random.random() < 0.3:
                new_length = int(len(segment) * np.random.uniform(0.95, 1.05))
                segment = resample(segment, new_length, axis=0)
                segment = resample(segment, samples_per_segment, axis=0)
        segments.append(segment)
        label = assign_label(annotation, dataset, i / fs, (i + samples_per_segment) / fs)
        if label is None:
            continue
        labels.append(label)

    if len(segments) == 0:
        logger.warning(f"No valid segments extracted from signal {dataset}")
        return np.array([]), []

    return np.array(segments), labels

def assign_label(annotation, dataset, start_time, end_time):
    class_map = {
        'NORM': 0, 'AF': 1, 'PVC': 2, 'PAC': 3, 'MI': 4,
        'LBBB': 5, 'RBBB': 6, 'I-AVB': 7, 'STTC': 8, 'HYP': 9
    }
    if dataset == 'mitdb':
        if not annotation.get('annotation'):
            logger.warning("No annotation provided for MIT-BIH segment")
            return class_map['NORM']
        ann = annotation['annotation']
        ann_in_segment = [
            ann.symbol[i] for i, s in enumerate(ann.sample)
            if start_time * 360 <= s < end_time * 360
        ]
        if not ann_in_segment:
            return class_map['NORM']
        for symbol in ['F', 'V', 'A', 'L', 'R']:
            if symbol in ann_in_segment:
                return class_map[{'F': 'AF', 'V': 'PVC', 'A': 'PAC', 'L': 'LBBB', 'R': 'RBBB'}[symbol]]
        return class_map['NORM']
    elif dataset == 'ptbxl':
        if not annotation.get('diagnostic_class'):
            logger.warning("No diagnostic class provided for PTB-XL segment")
            return class_map['NORM']
        diag = annotation.get('diagnostic_class', 'NORM')
        scp_codes = annotation.get('diagnostic_subclass', '')
        if scp_codes:
            try:
                scp_dict = ast.literal_eval(scp_codes) if isinstance(scp_codes, str) else {}
                for code, weight in scp_dict.items():
                    if float(weight) > 0 and code in class_map:
                        return class_map[code]
            except (ValueError, SyntaxError):
                logger.warning(f"Error parsing scp_codes: {scp_codes}")
        if diag in class_map:
            return class_map[diag]
        logger.warning(f"Unknown PTB-XL diagnosis: {diag}, defaulting to NORM")
        return class_map['NORM']
    elif dataset == 'cinc2020':
        diag_list = annotation.get('Dx', ['NORM'])
        snomed_map = {
            '426783006': 'AF', '59118001': 'AF',
            '164884008': 'PVC', '251173002': 'PVC',
            '427084000': 'PAC', '251165003': 'PAC',
            '164865005': 'MI', '54329005': 'MI',
            '429622005': 'LBBB', '426570008': 'LBBB',
            '426177001': 'RBBB', '426995002': 'RBBB',
            '270492004': 'I-AVB',
            '164947007': 'STTC', '429622': 'STTC',
            '251146004': 'HYP', '55827005': 'HYP',
            '10370003': 'NORM', '111288001': 'PAC', '11157007': 'AF',
            '111975006': 'STTC', '13640000': 'PAC', '164861001': 'MI',
            '164867002': 'MI', '164873001': 'HYP', '164889003': 'HYP',
            '164890007': 'HYP', '164895002': 'I-AVB', '164896001': 'LBBB',
            '164909002': 'RBBB', '164917005': 'STTC', '164921003': 'STTC',
            '164930006': 'STTC', '164931005': 'STTC', '164934002': 'STTC',
            '164937009': 'STTC', '164951009': 'STTC', '17338001': 'PVC',
            '195042002': 'NORM', '195060002': 'NORM', '195080001': 'NORM',
            '195101003': 'NORM', '195126007': 'NORM', '204384007': 'MI',
            '233917008': 'NORM', '251120003': 'NORM', '251139008': 'NORM',
            '251164006': 'NORM', '251168009': 'NORM', '251170000': 'NORM',
            '251173003': 'NORM', '251180001': 'NORM', '251182009': 'NORM',
            '251200008': 'NORM', '251259000': 'NORM', '251266004': 'NORM',
            '251268003': 'NORM', '253339007': 'NORM', '253352002': 'NORM',
            '266249003': 'NORM', '266257000': 'NORM', '270492004': 'NORM',
            '27885002': 'NORM', '282825002': 'NORM', '284470004': 'NORM',
            '29320008': 'NORM', '314208002': 'NORM', '368009': 'NORM',
            '370365005': 'NORM', '39732003': 'NORM', '413444003': 'NORM',
            '413844008': 'NORM', '425419005': 'NORM', '425623009': 'NORM',
            '425856008': 'NORM', '426177001': 'NORM', '426434006': 'NORM',
            '426627000': 'NORM', '426648003': 'NORM', '426664006': 'NORM',
            '426749004': 'NORM', '426761007': 'NORM', '426783006': 'NORM',
            '426995002': 'NORM', '427084000': 'NORM', '427172004': 'NORM',
            '427393009': 'NORM', '428417006': 'NORM', '428750005': 'NORM',
            '429622005': 'NORM', '445118002': 'NORM', '445211001': 'NORM',
            '446358003': 'NORM', '446813000': 'NORM', '47665007': 'NORM',
            '49260003': 'NORM', '49578007': 'STTC', '55930002': 'STTC',
            '57054005': 'MI', '59118001': 'RBBB', '59931005': 'STTC',
            '60423000': 'NORM', '63593006': 'HYP', '6374002': 'HYP',
            '65778007': 'I-AVB', '67198005': 'HYP', '67741000119109': 'STTC',
            '698247007': 'HYP', '698252002': 'HYP', '704997005': 'HYP',
            '713422000': 'HYP', '713426002': 'HYP', '713427006': 'HYP',
            '74390002': 'HYP', '74615001': 'HYP', '75532003': 'HYP',
            '77867006': 'HYP', '81898007': 'HYP', '82226007': 'HYP',
            '84114007': 'HYP', '89792004': 'HYP'
        }
        for d in diag_list:
            d = d.strip()
            if d in snomed_map and snomed_map[d] != 'NORM':
                if snomed_map[d] in class_map:
                    return class_map[snomed_map[d]]
                logger.warning(f"SNOMED code {d} mapped to {snomed_map[d]}, but not in class_map")
        return class_map['NORM']
    logger.warning(f"Invalid dataset: {dataset}")
    return None