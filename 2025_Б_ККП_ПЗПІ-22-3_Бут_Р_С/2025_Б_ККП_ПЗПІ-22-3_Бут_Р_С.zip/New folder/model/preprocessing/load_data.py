import os
import wfdb
import numpy as np
import pandas as pd
from scipy.signal import resample
from scipy.io import loadmat
import logging
import ast

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

def load_all_wfdb(data_dir, datasets=None, min_length=10.0, channels=[0, 1], target_fs=360):
    signals, annotations = [], []
    if datasets is None:
        datasets = ['mitdb', 'ptbxl', 'cinc2020']

    fallback_snomed_dict = {
        '426783006': 'AF', '59118001': 'AF',
        '164884008': 'PVC', '251173002': 'PVC',
        '427084000': 'PAC', '251165003': 'PAC',
        '164865005': 'MI', '54329005': 'MI',
        '429622005': 'LBBB', '426570008': 'LBBB',
        '426177001': 'RBBB', '426995002': 'RBBB',
        '270492004': 'I-AVB',
        '164947007': 'STTC', '429622': 'STTC',
        '251146004': 'HYP', '55827005': 'HYP'
    }

    cinc_mapping_path = os.path.join(data_dir, 'cinc2020', 'dx_mapping_scored.csv')
    if os.path.exists(cinc_mapping_path):
        cinc_mapping = pd.read_csv(cinc_mapping_path)
        snomed_dict = dict(zip(cinc_mapping['SNOMED CT Code'].astype(str), cinc_mapping['Abbreviation']))
    else:
        snomed_dict = fallback_snomed_dict
        logger.warning("dx_mapping_scored.csv not found, using fallback SNOMED mapping")

    if 'mitdb' in datasets:
        mitdb_dir = os.path.join(data_dir, 'mitdb')
        logger.info(f"Checking MIT-BIH directory: {mitdb_dir}")
        if os.path.exists(mitdb_dir):
            records = [f.split('.')[0] for f in os.listdir(mitdb_dir) if f.endswith('.hea')]
            logger.info(f"Found {len(records)} MIT-BIH .hea files")
            for rec in records:
                file_path = os.path.join(mitdb_dir, rec)
                if not os.path.exists(file_path + '.hea') or not os.path.exists(file_path + '.dat'):
                    logger.warning(f"Missing files for {file_path}")
                    continue
                signal, annotation = load_wfdb(file_path, target_fs, min_length, channels)
                if signal is None:
                    logger.warning(f"Failed to load signal {rec}")
                    continue
                signals.append(signal)
                annotations.append({'dataset': 'mitdb', 'annotation': annotation})
                logger.info(f"Loaded MIT-BIH signal {rec}, shape: {signal.shape}")
        else:
            logger.error(f"MIT-BIH dataset directory not found: {mitdb_dir}")

    if 'ptbxl' in datasets:
        ptbxl_dir = os.path.join(data_dir, 'ptbxl')
        csv_path = os.path.join(ptbxl_dir, 'ptbxl_database.csv')
        scp_statements_path = os.path.join(ptbxl_dir, 'scp_statements.csv')
        if os.path.exists(csv_path) and os.path.exists(scp_statements_path):
            logger.info(f"Scanning PTB-XL dataset: {ptbxl_dir}")
            df = pd.read_csv(csv_path)
            scp_statements = pd.read_csv(scp_statements_path)
            scp_statements = scp_statements[scp_statements['diagnostic'] == 1]
            logger.info(f"Columns in scp_statements.csv: {list(scp_statements.columns)}")
            scp_col = next((col for col in ['scp_codes', 'Unnamed: 0', 'code'] if col in scp_statements.columns), None)
            if scp_col is None or 'diagnostic_class' not in scp_statements.columns:
                logger.warning(f"scp_statements.csv is missing SCP code column or 'diagnostic_class'")
                scp_class_map = {}
            else:
                scp_class_map = dict(zip(scp_statements[scp_col], scp_statements['diagnostic_class']))
            for _, row in df.iterrows():
                file_path = os.path.join(ptbxl_dir, row['filename_lr'])
                if not os.path.exists(file_path + '.hea') or not os.path.exists(file_path + '.dat'):
                    logger.warning(f"PTB-XL file not found: {file_path}")
                    continue
                signal, _ = load_wfdb(file_path, target_fs, min_length, channels)
                if signal is None:
                    logger.warning(f"Failed to load PTB-XL signal {file_path}")
                    continue
                scp_codes = row['scp_codes']
                diag_class = 'NORM'
                diag_subclass = ''
                try:
                    scp_dict = ast.literal_eval(scp_codes) if isinstance(scp_codes, str) else {}
                    for code, weight in scp_dict.items():
                        if float(weight) > 0 and code in scp_class_map:
                            diag_class = scp_class_map.get(code, 'NORM')
                            diag_subclass = code
                            break
                except (ValueError, SyntaxError) as e:
                    logger.warning(f"Error parsing scp_codes for {file_path}: {e}")
                signals.append(signal)
                annotations.append({
                    'dataset': 'ptbxl',
                    'diagnostic_class': diag_class,
                    'diagnostic_subclass': diag_subclass,
                    'ecg_id': row['ecg_id']
                })
                logger.info(f"Loaded PTB-XL signal {file_path}, diag: {diag_class}, shape: {signal.shape}")
            logger.warning(f"PTB-XL files not found: {csv_path}, {scp_statements_path}. Scanning recursively...")
            for root, _, files in os.walk(ptbxl_dir):
                hea_files = [f[:-4] for f in files if f.endswith('.hea')]
                for rec in hea_files:
                    file_path = os.path.join(root, rec)
                    signal, _ = load_wfdb(file_path, target_fs, min_length, channels)
                    if signal is None:
                        logger.warning(f"Failed to load PTB-XL signal {file_path}")
                        continue
                    signals.append(signal)
                    annotations.append({
                        'dataset': 'ptbxl',
                        'diagnostic_class': 'NORM',
                        'diagnostic_subclass': ''
                    })
                    logger.info(f"Loaded PTB-XL signal {file_path}, diag: NORM (recursive), shape: {signal.shape}")

    if 'cinc2020' in datasets:
        cinc_dir = os.path.join(data_dir, 'cinc2020', 'training')
        if os.path.exists(cinc_dir):
            logger.info(f"Scanning CinC 2020 dataset: {cinc_dir}")
            for root, _, files in os.walk(cinc_dir):
                hea_files = [f[:-4] for f in files if f.endswith('.hea')]
                for rec in hea_files:
                    file_path = os.path.join(root, rec)
                    signal = load_cinc_signal(file_path, target_fs, min_length, channels)
                    if signal is None:
                        logger.warning(f"Failed to load CinC 2020 signal {rec}")
                        continue
                    dx = []
                    for encoding in ['utf-8', 'latin-1', 'iso-8859-1']:
                        try:
                            with open(file_path + '.hea', 'r', encoding=encoding) as f:
                                header = f.readlines()
                                dx_line = next((l for l in header if l.strip().startswith('# Dx:')), '')
                                if dx_line:
                                    dx = dx_line.split(':', 1)[1].strip().split(',')
                                    dx = [d.strip() for d in dx if d.strip()]
                                    logger.info(f"Parsed Dx for {rec}: {dx}")
                                    break
                                else:
                                    logger.warning(f"No # Dx: line found in {rec}.hea")
                            break
                        except UnicodeDecodeError:
                            continue
                    if not dx:
                        dx = [next((code for code, diag in snomed_dict.items() if diag in os.path.basename(file_path)), 'NORM')]
                        logger.info(f"Fallback to SNOMED mapping for {rec}: {dx}")
                    signals.append(signal)
                    annotations.append({'dataset': 'cinc2020', 'Dx': dx})
                    logger.info(f"Loaded CinC 2020 signal {rec}, diag: {dx}, shape: {signal.shape}")
            logger.info(f"Loaded {len([a for a in annotations if a['dataset'] == 'cinc2020'])} signals from CinC 2020")
        else:
            logger.error(f"CinC 2020 dataset directory not found: {cinc_dir}")

    logger.info(f"Total loaded {len(signals)} signals")
    return signals, annotations

def load_wfdb(file_path, target_fs=360, min_length=10.0, channels=[0, 1]):
    """
    Load a WFDB record and its annotations.

    Parameters:
    -----------
    file_path : str
        Path to the WFDB record (without extension).
    target_fs : int
        Target sampling frequency (default: 360 Hz).
    min_length : float
        Minimum signal duration in seconds (default: 10.0).
    channels : list of int
        Channel indices to select (default: [0, 1]).

    Returns:
    --------
    signal : numpy.ndarray
        ECG signal array or None if loading fails.
    annotation : object
        WFDB annotation object or None.
    """
    try:
        record = wfdb.rdsamp(file_path)
        if record is None or record[0] is None:
            logger.error(f"No signal data loaded for WFDB record {file_path}")
            return None, None
        num_channels = record[0].shape[1] if len(record[0].shape) > 1 else 1
        if num_channels < max(channels) + 1:
            logger.error(f"Insufficient channels in {file_path}: available {num_channels}, required {max(channels) + 1}")
            return None, None
        signal = record[0][:, channels]
        if signal is None or len(signal) == 0:
            logger.error(f"Empty or invalid signal data for WFDB record {file_path}")
            return None, None
        fs = record[1]['fs']
        duration = len(signal) / fs
        if duration < min_length:
            logger.warning(f"Signal {file_path} too short: {duration:.2f}s, required {min_length}s")
            return None, None
        if np.any(np.isnan(signal)) or np.any(np.isinf(signal)):
            logger.warning(f"Signal {file_path} contains NaN or Inf, replacing with zeros")
            signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)
        if fs != target_fs:
            signal = resample(signal, int(len(signal) * target_fs / fs), axis=0)
        annotation = None
        if os.path.exists(file_path + '.atr'):
            annotation = wfdb.rdann(file_path, 'atr')
            logger.info(f"Loaded annotation for {file_path}")
        return signal, annotation
    except IndexError as e:
        logger.error(f"Index error loading WFDB record {file_path}: {str(e)}")
        return None, None
    except Exception as e:
        logger.error(f"Error loading WFDB record {file_path}: {str(e)}")
        return None, None

def load_cinc_signal(file_path, target_fs=360, min_length=10.0, channels=[0, 1]):
    """
    Load a CinC 2020 signal from .mat file.

    Parameters:
    -----------
    file_path : str
        Path to the CinC signal (without extension).
    target_fs : int
        Target sampling frequency (default: 360 Hz).
    min_length : float
        Minimum signal duration in seconds (default: 10.0).
    channels : list of int
        Channel indices to select (default: [0, 1]).

    Returns:
    --------
    signal : numpy.ndarray
        ECG signal array or None if loading fails.
    """
    try:
        mat_data = loadmat(file_path + '.mat')
        signal = mat_data['val'][channels, :].T
        for encoding in ['utf-8', 'latin-1', 'iso-8859-1']:
            try:
                with open(file_path + '.hea', 'r', encoding=encoding) as f:
                    header = f.readlines()
                    fs = float(next(l.split()[2] for l in header if l.startswith(os.path.basename(file_path))))
                    break
            except UnicodeDecodeError:
                continue
        duration = len(signal) / fs
        if duration < min_length:
            logger.warning(f"CinC signal {file_path} too short: {duration:.2f}s, required {min_length}s")
            return None
        if np.any(np.isnan(signal)) or np.any(np.isinf(signal)):
            logger.warning(f"Signal {file_path} contains NaN or Inf, replacing with zeros")
            signal = np.nan_to_num(signal, nan=0.0, posinf=0.0, neginf=0.0)
        if fs != target_fs:
            signal = resample(signal, int(len(signal) * target_fs / fs), axis=0)
        return signal
    except Exception as e:
        logger.error(f"Error loading CinC signal {file_path}: {e}")
        return None