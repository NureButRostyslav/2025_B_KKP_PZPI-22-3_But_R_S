from sklearn.metrics import classification_report
import numpy as np

def evaluate_model(model, X_test, y_test):
    X_test = X_test[..., np.newaxis]
    predictions = np.argmax(model.predict(X_test), axis=1)
    print(classification_report(y_test, predictions, target_names=['Normal', 'PVC', 'PAC', 'AF', 'LBBB', 'RBBB', 'MI', 'HYP', 'CD', 'STTC']))