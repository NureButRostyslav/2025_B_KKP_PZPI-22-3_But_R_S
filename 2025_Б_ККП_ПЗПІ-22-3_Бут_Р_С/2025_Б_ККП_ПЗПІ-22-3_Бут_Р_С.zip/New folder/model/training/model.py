from tensorflow.keras import models, layers
from tensorflow.keras import regularizers
import tensorflow as tf


class MacroF1Score(tf.keras.metrics.Metric):

    def __init__(self, num_classes, name='macro_f1_score', **kwargs):
        super(MacroF1Score, self).__init__(name=name, **kwargs)
        self.num_classes = num_classes
        self.true_positives = self.add_weight(name='tp', shape=(num_classes,), initializer='zeros')
        self.false_positives = self.add_weight(name='fp', shape=(num_classes,), initializer='zeros')
        self.false_negatives = self.add_weight(name='fn', shape=(num_classes,), initializer='zeros')

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_true = tf.cast(tf.argmax(y_true, axis=-1), tf.int32)  # [batch_size]
        y_pred = tf.cast(tf.argmax(y_pred, axis=-1), tf.int32)  # [batch_size]

        matches = tf.equal(y_true, y_pred)  # [batch_size]
        matches = tf.cast(tf.expand_dims(matches, -1), tf.bool)  # [batch_size, 1]

        true_class = tf.expand_dims(y_true, -1)  # [batch_size, 1]
        pred_class = tf.expand_dims(y_pred, -1)  # [batch_size, 1]
        class_range = tf.range(self.num_classes, dtype=tf.int32)  # [num_classes]

        # True positives: y_true == y_pred == class
        true_class_eq = tf.equal(true_class, class_range)  # [batch_size, num_classes]
        tp = tf.reduce_sum(tf.cast(tf.logical_and(matches, true_class_eq), tf.float32), axis=0)  # [num_classes]

        # False positives: y_true != class, y_pred == class
        pred_class_eq = tf.equal(pred_class, class_range)  # [batch_size, num_classes]
        not_true_class_eq = tf.logical_not(true_class_eq)  # [batch_size, num_classes]
        fp = tf.reduce_sum(tf.cast(tf.logical_and(not_true_class_eq, pred_class_eq), tf.float32),
                           axis=0)  # [num_classes]

        # False negatives: y_true == class, y_pred != class
        not_pred_class_eq = tf.logical_not(pred_class_eq)  # [batch_size, num_classes]
        fn = tf.reduce_sum(tf.cast(tf.logical_and(true_class_eq, not_pred_class_eq), tf.float32),
                           axis=0)  # [num_classes]

        # Update state variables
        self.true_positives.assign_add(tp)
        self.false_positives.assign_add(fp)
        self.false_negatives.assign_add(fn)

    def result(self):
        precision = self.true_positives / (self.true_positives + self.false_positives + 1e-10)
        recall = self.true_positives / (self.true_positives + self.false_negatives + 1e-10)
        f1 = 2 * (precision * recall) / (precision + recall + 1e-10)
        return tf.reduce_mean(f1)

    def reset_state(self):
        self.true_positives.assign(tf.zeros(self.num_classes))
        self.false_positives.assign(tf.zeros(self.num_classes))
        self.false_negatives.assign(tf.zeros(self.num_classes))


def build_classifier(input_shape=(3600, 2), num_classes=10):

    inputs = layers.Input(shape=input_shape)
    x = layers.BatchNormalization()(inputs)

    # Residual block 1
    x1 = layers.Conv1D(64, 7, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x)
    x1 = layers.BatchNormalization()(x1)
    x1 = layers.Conv1D(64, 7, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x1)
    x1 = layers.BatchNormalization()(x1)
    x_shortcut = layers.Conv1D(64, 1, padding='same')(x)
    x = layers.Add()([x1, x_shortcut])
    x = layers.MaxPooling1D(2)(x)

    # Residual block 2
    x1 = layers.Conv1D(32, 5, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x)
    x1 = layers.BatchNormalization()(x1)
    x1 = layers.Conv1D(32, 5, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x1)
    x1 = layers.BatchNormalization()(x1)
    x_shortcut = layers.Conv1D(32, 1, padding='same')(x)
    x = layers.Add()([x1, x_shortcut])
    x = layers.MaxPooling1D(2)(x)

    # Residual block 3
    x1 = layers.Conv1D(16, 3, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x)
    x1 = layers.BatchNormalization()(x1)
    x1 = layers.Conv1D(16, 3, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x1)
    x1 = layers.BatchNormalization()(x1)
    x_shortcut = layers.Conv1D(16, 1, padding='same')(x)
    x = layers.Add()([x1, x_shortcut])
    x = layers.MaxPooling1D(2)(x)

    # Residual block 4
    x1 = layers.Conv1D(16, 3, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x)
    x1 = layers.BatchNormalization()(x1)
    x1 = layers.Conv1D(16, 3, padding='same', activation='relu',
                       kernel_regularizer=regularizers.l2(0.005))(x1)
    x1 = layers.BatchNormalization()(x1)
    x_shortcut = layers.Conv1D(16, 1, padding='same')(x)
    x = layers.Add()([x1, x_shortcut])

    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(256, activation='relu', kernel_regularizer=regularizers.l2(0.005))(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation='softmax')(x)

    model = models.Model(inputs, outputs)
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy', MacroF1Score(num_classes=num_classes)])
    return model