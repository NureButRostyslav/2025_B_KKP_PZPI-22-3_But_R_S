import os
import logging
import signal
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, f1_score, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight
from scipy.signal import resample
import seaborn as sns
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from model.preprocessing.load_data import load_all_wfdb
from model.preprocessing.preprocess import preprocess_signal
from model.training.model import build_classifier

log_dir = r"D:\ecg_tachycardia_detection\logs\fit"
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, "train_log.txt")

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if logger.handlers:
    logger.handlers.clear()

file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8', delay=False)
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.DEBUG)
stream_handler.setFormatter(file_formatter)
logger.addHandler(stream_handler)

logger.debug("Script train.py started")
if logger.handlers:
    logger.handlers[0].flush()

def signal_handler(sig, frame):
    logger.info("Script interrupted by Ctrl+C, flushing logs")
    for handler in logger.handlers:
        handler.flush()
        handler.close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

class ECGGenerator(tf.keras.utils.Sequence):
    def __init__(self, segments, labels, batch_size=32, num_classes=None, augment=False):
        self.segments = segments
        self.num_classes = num_classes or max(labels) + 1
        self.labels = to_categorical(labels, num_classes=self.num_classes)
        self.batch_size = batch_size
        self.indices = np.arange(len(self.segments))
        self.augment = augment
        if len(self.segments) == 0:
            logger.error("No valid segments provided")
            if logger.handlers:
                logger.handlers[0].flush()
            raise ValueError("No valid segments")

    def __len__(self):
        return int(np.ceil(len(self.segments) / self.batch_size))

    def __getitem__(self, idx):
        batch_indices = self.indices[idx * self.batch_size:(idx + 1) * self.batch_size]
        X = self.segments[batch_indices]
        y = self.labels[batch_indices]
        if self.augment:
            X = np.array([self._augment_segment(x) for x in X])
        return X, y

    def _augment_segment(self, segment):
        segment += np.random.normal(0, 0.01, segment.shape)
        scale = np.random.uniform(0.9, 1.1)
        segment *= scale
        shift = np.random.uniform(-0.1, 0.1)
        segment += shift
        if np.random.random() < 0.3:
            new_length = int(len(segment) * np.random.uniform(0.95, 1.05))
            segment = resample(segment, new_length, axis=0)
            segment = resample(segment, 3600, axis=0)
        if segment.shape[0] != 3600:
            logger.warning(f"Segment shape mismatch: {segment.shape}, resampling to (3600, {segment.shape[1]})")
            if logger.handlers:
                logger.handlers[0].flush()
            segment = resample(segment, 3600, axis=0)
        return segment

def train_model(data_dir):
    logger.debug("Starting train_model function")
    logger.info(f"Using data directory: {os.path.abspath(data_dir)}")
    if logger.handlers:
        logger.handlers[0].flush()
    try:
        logger.info("Loading data")
        signals, annotations = load_all_wfdb(data_dir, datasets=['mitdb', 'ptbxl', 'cinc2020'], channels=[0, 1])
        if logger.handlers:
            logger.handlers[0].flush()
        if not signals:
            logger.error("No signals loaded from data directory")
            if logger.handlers:
                logger.handlers[0].flush()
            raise ValueError("No signals loaded")

        all_segments, all_labels = [], []
        for i, (signal, annotation) in enumerate(zip(signals, annotations)):
            dataset = annotation['dataset']
            logger.info(f"Processing signal {i+1}/{len(signals)} from {dataset}, shape: {signal.shape}")
            segments, labels = preprocess_signal(signal, fs=360, segment_length=10, dataset=dataset,
                                               annotation=annotation, augment=True)
            if len(segments) == 0:
                logger.warning(f"No valid segments extracted from signal {dataset}")
                if logger.handlers:
                    logger.handlers[0].flush()
                continue
            all_segments.append(segments)
            all_labels.extend(labels)

        all_segments = np.concatenate(all_segments) if all_segments else np.array([])
        all_labels = np.array(all_labels)

        if len(all_segments) == 0:
            logger.error("No valid segments after preprocessing")
            if logger.handlers:
                logger.handlers[0].flush()
            raise ValueError("No valid segments after preprocessing")

        unique_labels = np.unique(all_labels)
        num_classes = len(unique_labels)
        class_names = ['Normal', 'AF', 'PVC', 'PAC', 'MI', 'LBBB', 'RBBB', 'I-AVB', 'STTC', 'HYP']
        class_counts = np.bincount(all_labels, minlength=10)
        logger.info(f"Processed {len(all_segments)} segments with {num_classes} classes")
        for i, count in enumerate(class_counts):
            logger.info(f"Class {class_names[i]}: {count} segments")
        if logger.handlers:
            logger.handlers[0].flush()

        if np.any(all_labels < 0) or np.any(all_labels >= num_classes):
            logger.error(f"Invalid labels detected: {all_labels}")
            if logger.handlers:
                logger.handlers[0].flush()
            raise ValueError("Invalid labels detected")

        label_map = {old_label: new_label for new_label, old_label in enumerate(unique_labels)}
        all_labels = np.array([label_map.get(label, 0) for label in all_labels])
        used_class_names = [class_names[i] for i in unique_labels]

        X_train_val, X_test, y_train_val, y_test = train_test_split(
            all_segments, all_labels, test_size=0.1, random_state=42, stratify=all_labels
        )
        try:
            X_train, X_val, y_train, y_val = train_test_split(
                X_train_val, y_train_val, test_size=0.2, random_state=42, stratify=y_train_val
            )
        except ValueError as e:
            logger.warning(f"Stratify failed for train/val split: {e}. Using non-stratified split.")
            if logger.handlers:
                logger.handlers[0].flush()
            X_train, X_val, y_train, y_val = train_test_split(
                X_train_val, y_train_val, test_size=0.2, random_state=42
            )

        logger.info(f"Train segments: {len(X_train)}, Validation segments: {len(X_val)}, Test segments: {len(X_test)}")
        if logger.handlers:
            logger.handlers[0].flush()

        class_weights = compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
        class_weight_dict = {i: w for i, w in enumerate(class_weights)}
        logger.info(f"Class weights: {class_weight_dict}")
        if logger.handlers:
            logger.handlers[0].flush()

        train_gen = ECGGenerator(X_train, y_train, batch_size=32, num_classes=num_classes, augment=True)
        val_gen = ECGGenerator(X_val, y_val, batch_size=32, num_classes=num_classes, augment=False)
        test_gen = ECGGenerator(X_test, y_test, batch_size=32, num_classes=num_classes, augment=False)

        model = build_classifier(input_shape=(3600, 2), num_classes=num_classes)
        early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
        checkpoint = ModelCheckpoint(
            os.path.join(os.path.dirname(__file__), '../../saved_models/classifier_model.h5'),
            monitor='val_loss', save_best_only=True
        )
        lr_scheduler = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6)
        model.fit(
            train_gen,
            validation_data=val_gen,
            epochs=15,
            callbacks=[early_stopping, checkpoint, lr_scheduler],
            class_weight=class_weight_dict
        )

        y_pred = model.predict(test_gen)
        y_pred_classes = np.argmax(y_pred, axis=1)
        y_test_classes = np.argmax(to_categorical(y_test, num_classes=num_classes), axis=1)
        logger.info("\nClassification Report:")
        logger.info(classification_report(y_test_classes, y_pred_classes, target_names=used_class_names))
        logger.info(f"F1-score (macro): {f1_score(y_test_classes, y_pred_classes, average='macro'):.2f}")
        if logger.handlers:
            logger.handlers[0].flush()

        cm = confusion_matrix(y_test_classes, y_pred_classes)
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=used_class_names, yticklabels=used_class_names)
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.savefig(os.path.join(os.path.dirname(__file__), '../../saved_models/confusion_matrix.png'))
        plt.close()

        save_path = os.path.join(os.path.dirname(__file__), '../../saved_models/classifier_model.h5')
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        model.save(save_path)
        logger.info(f"Model saved to {save_path}")
        if logger.handlers:
            logger.handlers[0].flush()
        return model

    except Exception as e:
        logger.error(f"Error during training: {str(e)}")
        if logger.handlers:
            logger.handlers[0].flush()
        raise

if __name__ == "__main__":
    DATA_DIR = r"D:\ecg_tachycardia_detection\data\test_raw"
    train_model(DATA_DIR)