SYMPTOMS = {
    'normal': {
        'description': 'Normal rhythm',
        'symptoms': 'No symptoms, regular heartbeat.'
    },
    'af': {
        'description': 'Atrial fibrillation',
        'symptoms': 'Irregular heartbeat, rapid pulse, fatigue, shortness of breath.'
    },
    'pvc': {
        'description': 'Premature ventricular contraction',
        'symptoms': 'Sensation of skipped beats, palpitations.'
    },
    'pac': {
        'description': 'Premature atrial contraction',
        'symptoms': 'Mild palpitations, slight discomfort.'
    },
    'mi': {
        'description': 'Myocardial infarction',
        'symptoms': 'Chest pain, shortness of breath, sweating, nausea.'
    },
    'lbbb': {
        'description': 'Left bundle branch block',
        'symptoms': 'Often asymptomatic, sometimes fatigue or dizziness.'
    },
    'rbbb': {
        'description': 'Right bundle branch block',
        'symptoms': 'Usually asymptomatic, sometimes mild weakness.'
    },
    'i-avb': {
        'description': 'First-degree AV block',
        'symptoms': 'Often asymptomatic, sometimes mild fatigue.'
    },
    'sttc': {
        'description': 'ST/T changes',
        'symptoms': 'Chest pain, discomfort, possible ischemia.'
    },
    'hyp': {
        'description': 'Hypertrophy',
        'symptoms': 'High blood pressure, headache, shortness of breath.'
    }
}