import tensorflow as tf
import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_model(model_path):
    try:
        model = tf.keras.models.load_model(model_path)
        logger.info(f"Модель завантажено з {model_path}")
        return model
    except Exception as e:
        logger.error(f"Помилка завантаження моделі: {e}")
        raise

def predict(model, segments):
    try:
        predictions = model.predict(segments, batch_size=16, verbose=0)
        logger.info(f"Згенеровано передбачення для {len(segments)} сегментів")
        return predictions
    except Exception as e:
        logger.error(f"Помилка під час передбачення: {e}")
        raise